import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _8bfd3682 = () => interopDefault(import('..\\pages\\hotjoon.vue' /* webpackChunkName: "pages/hotjoon" */))
const _064cd130 = () => interopDefault(import('..\\pages\\inspire.vue' /* webpackChunkName: "pages/inspire" */))
const _5b88bec0 = () => interopDefault(import('..\\pages\\namyoung.vue' /* webpackChunkName: "pages/namyoung" */))
const _75501cc2 = () => interopDefault(import('..\\pages\\namyoung2.vue' /* webpackChunkName: "pages/namyoung2" */))
const _2f47d6e0 = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages/index" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/hotjoon",
    component: _8bfd3682,
    name: "hotjoon"
  }, {
    path: "/inspire",
    component: _064cd130,
    name: "inspire"
  }, {
    path: "/namyoung",
    component: _5b88bec0,
    name: "namyoung"
  }, {
    path: "/namyoung2",
    component: _75501cc2,
    name: "namyoung2"
  }, {
    path: "/",
    component: _2f47d6e0,
    name: "index"
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
